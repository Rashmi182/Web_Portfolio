/* Image changing */
function changeImage() 
{
    var image = document.getElementById("profileImage");
    if (image.src.match("profile.jpg")) {
        image.src = "logo1.jpg"; // Replace with the path to your new image
    } 
    else {
        image.src = "profile.jpg";
    }
}

function show() {
    /* Access image by id and change 
    the display property to block*/
    document.getElementById('img')
        .style.display = "block";
    document.getElementById('btnID')
        .style.display = "none";
}

/* Skill set bar */
document.addEventListener("DOMContentLoaded", function () {

    // Frontend Skills Chart
    const frontendCtx = document.getElementById('frontendChart').getContext('2d');
    new Chart(frontendCtx, {
        type: 'bar',
        data: {
            labels: ['HTML', 'CSS', 'JavaScript'],
            datasets: [{
                label: 'Proficiency Level',
                data: [98, 93, 75],
                backgroundColor: ['#9C27B0', '#00BCD4', '#FF9800'],
                borderColor: '#ddd',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, max: 100, title: { display: true, text: 'Proficiency (%)' } }
            },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${context.label}: ${context.raw}%` } } }
        }
    });

    // Backend Skills Chart
    const backendCtx = document.getElementById('backendChart').getContext('2d');
    new Chart(backendCtx, {
        type: 'bar',
        data: {
            labels: ['Java', 'JDBC', 'JSP', 'MySQL'],
            datasets: [{
                label: 'Proficiency Level',
                data: [92, 75, 70, 90],
                backgroundColor: ['#4CAF50', '#FFC107', '#2196F3', '#FF5722'],
                borderColor: '#ddd',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, max: 100, title: { display: true, text: 'Proficiency (%)' } },
            },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${context.label}: ${context.raw}%` } } }
        }
    });

    // Tools & Technologies Chart
    const toolsCtx = document.getElementById('toolsChart').getContext('2d');
    new Chart(toolsCtx, {
        type: 'bar',
        data: {
            labels: ['Git', 'GitHub', 'Jira'],
            datasets: [{
                label: 'Proficiency Level',
                data: [75, 85, 65],
                backgroundColor: ['#3F51B5', '#8BC34A', '#607D8B'],
                borderColor: '#ddd',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: { beginAtZero: true, max: 100, title: { display: true, text: 'Proficiency (%)' } },
            },
            plugins: { legend: { display: false }, tooltip: { callbacks: { label: (context) => `${context.label}: ${context.raw}%` } } }
        }
    });

    document.getElementById("contactForm").addEventListener("submit", function(event) {
        event.preventDefault();  // Prevent the form from refreshing the page
    
        // Optionally, you can perform form validation here
        // Example: validate if inputs are not empty, etc.
        
        // If form is valid, show success message
        document.getElementById("responseMessage").style.display = "block";
    
        // Optionally, you can clear the form
        document.getElementById("contactForm").reset();
    });
});
